from django.contrib import admin
from portfolio.api.portfolio_rest.models import PostFilter

# Register your models here.

admin.site.register(PostFilter)